secret = 7
guess = int(input("Guess a number between 0 and 10!: "))

while guess != secret:
  if guess < secret:
    print("The number you guessed is too low!")
  else:
    print("The number you guessed is too high!")
  guess = int(input("Guess a number between 0 and 10!"))

print("Congratulations! You guessed the secret number!: ")


green = "no"
small = "no"

green = input("Is the color green? (yes/no): ")
small = input("Is the size small? (yes/no): ")

if green == "yes":
  if small == "yes":
    print("We have found the Pea!")
  else:
    print("We have found the Watermelon!")
else:
  if small == "yes":
    print("We have found the Cherry!")
  else:
    print("We have found the pumpkin!")


num = [0,1,2,3,4,5,6,7,8,9,10]

for x in range(0,11):
  print(x)


guess_me = 7
number = 1

while number <= guess_me:
  if number < guess_me:
    print("Too low!")
  elif number == guess_me:
    print("Found it!")
  else:
    print("Oops!")
  number += 1


guess_me = 5
for number in range(10):
  if number < guess_me:
    print('too low')
  elif number == guess_me:
    print('found it!')
    break
  else:
    print('oops')
    break