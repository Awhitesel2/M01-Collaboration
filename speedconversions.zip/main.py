hours = int(input("Enter Hours: "))
seconds_in_a_hour = hours * 60 * 60
print("There are " + str(seconds_in_a_hour) + " seconds in " + str(hours) + " hours")


days = int(input("Enter Days: "))
hours_ina_day = days * 24
seconds_in_a_day = hours_ina_day * 60 * 60
print("There are " + str(seconds_in_a_day) + " seconds in " + str(days) + " days")

Divison = seconds_in_a_day / seconds_in_a_hour
print(Divison)

Divison1 = seconds_in_a_day // seconds_in_a_hour
print(Divison1)