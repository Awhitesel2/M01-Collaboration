years_list = [2004, 2005, 2006, 2007, 2008, 2009]

print("in the year " + str(years_list[2]) + " you were 3 years old")
print("in the year " + str(years_list[5]) + " you were the oldest")

things = ["mozzarella", "cinderella", "salmonella"]

things[1] = things[1].capitalize()
print(things)

things[0] = things[0].upper()
print(things)

del things[2]
print(things)


def good():
    return ['Harry', 'Ron', 'Hermione']

def get_odds():
    for i in range(10):
        if i % 2 != 0:
            yield i

for i, number in enumerate(get_odds()):
    if i == 2:
        print(number)