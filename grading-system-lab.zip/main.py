while True:
    last_name = input("Enter student's last name (or 'ZZZ' to quit): ")
    if last_name == 'ZZZ':
        break
    first_name = input("Enter student's first name: ")
    gpa = float(input("Enter student's GPA: "))
    if gpa >= 3.5:
        print(f"{first_name} {last_name} made the Dean's List!")
    if gpa >= 3.25:
        print(f"{first_name} {last_name} made the Honor Roll!")